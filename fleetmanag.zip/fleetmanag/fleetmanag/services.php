<!DOCTYPE html>
<html lang="en">

<?php include("vendor/inc/head.php");?>

<body>

  <!-- Navigation -->
  <?php include("vendor/inc/nav.php");?>

  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">Services
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.php">Home</a>
      </li>
      <li class="breadcrumb-item active">Services</li>
    </ol>

    <!-- Image Header -->
    <img class="img-fluid rounded mb-4" src="vendor/img/placeholder.png" alt="">

    <!-- Marketing Icons Section -->
    <div class="row">
      <div class="col-lg-4 mb-4">
        <div class="card h-100">
          <h4 class="card-header">Modes de transport améliorés</h4>
          <div class="card-body">
            <p class="card-text">
            Nous améliorons l'accès aux transports publics pour toutes les personnes et organisations en renforçant
               Les conditions sont réunies pour des modes de transport durables.
            </p>
          </div>
          
        </div>
      </div>
      <div class="col-lg-4 mb-4">
        <div class="card h-100">
          <h4 class="card-header">Des voyages plus rapides et plus sûrs</h4>
          <div class="card-body">
            <p class="card-text">
            Nos voyages réduisent la croissance du trafic et les embouteillages en réalisant un transfert modal du transport privé
               déplacements en véhicules motorisés vers un mode de transport plus efficace et plus durable.
            </p>
          </div>
          
        </div>
      </div>
      <div class="col-lg-4 mb-4">
        <div class="card h-100">
          <h4 class="card-header">La mise en réseau</h4>
          <div class="card-body">
            <p class="card-text">
            Créer un réseau de transport public multimodal efficace qui facilitera la
               interconnexion et interopérabilité du réseau de transport associé.
            </p>
          </div>
          
        </div>
      </div>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <?php include("vendor/inc/footer.php");?>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

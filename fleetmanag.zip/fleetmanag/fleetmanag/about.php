<!DOCTYPE html>
<html lang="en">

<?php include("vendor/inc/head.php");?>

<body>

  <!-- Navigation -->
  <?php include("vendor/inc/nav.php");?>

  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">A PROPOS
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.php">Home</a>
      </li>
      <li class="breadcrumb-item active"> A PROPOS</li>
    </ol>

    <!-- Intro Content -->
    <div class="row">
      <div class="col-lg-6">
        <img class="img-fluid rounded mb-4" src="vendor/img/placeholder-1.png" alt="">
      </div>
      <div class="col-lg-6">
        <h2>A PROPOS DE NOUS</h2>
        <p>
        Le système de gestion de flottes de véhicules est un système conçu pour traiter les problèmes rencontrés dans
            transport. Les principaux problèmes rencontrés dans ce secteur du transport sont tels que la répartition des tâches,
            suivi des véhicules, attribution d'itinéraires, paiement, commande de réservation, accusé de réception, génération
            réception des transactions, surmenage des employés, sécurité des marchandises, des utilisateurs, des chauffeurs et aussi
            entretien des véhicules en termes de financement et de consommation de temps. Système de réservation de véhicules
            sera capable de résoudre des problèmes majeurs tels que l'attribution des tâches où par un GPRS
            être monté dans tous les véhicules et cabines pour garantir que chaque véhicule et cabine est tracé et
            assigné une tâche à la fois, gardez également une trace de tous les rapports financiers et des dépenses engagées dans le
            organisation en veillant à ce que tous les paiements soient effectués par carte de crédit/débit ou par paiement de facture. Le
            le système pourra avoir des détails sur tous les clients qui ont réservé un véhicule et également voir
            les véhicules avec des tâches à accomplir et ceux qui n'en ont pas.
        </p>
      </div>
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->

  <!-- Footer -->
<?php include("vendor/inc/footer.php");?>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
